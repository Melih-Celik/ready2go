# Buf plugin

This plugin adds completion for [Buf CLI](https://github.com/bufbuild/buf), a tool working with Protocol Buffers.

To use it, add `buf` to the plugins array in your zshrc file:

```zsh
plugins=(... buf)
```