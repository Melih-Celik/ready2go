# Samtools plugin

This plugin adds support for [samtools](http://www.htslib.org/):

* Adds autocomplete options for all samtools sub commands.
